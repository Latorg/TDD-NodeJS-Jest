const axios = require('./axios')

module.exports = {
    axios
}