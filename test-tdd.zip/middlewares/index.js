const authenticate = require('./authenticate');

module.exports = {
    authenticate
};